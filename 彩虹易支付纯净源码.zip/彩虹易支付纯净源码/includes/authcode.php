<?php
define('authcode','1b128e0323c406ab3ff3b053b0774fd5');

?>